import React from 'react';
import './YellowButton.scss'

export default function YellowButton(props) {
    return (
        <React.Fragment>
            <button className="YellowButton" onClick={props.clicked}>{props.text}</button>
        </React.Fragment>
    )
}
