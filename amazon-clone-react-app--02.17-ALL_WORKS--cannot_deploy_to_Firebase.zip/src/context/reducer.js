export const initialState = {
    basket: [],
    user: null
}

export const getBasketTotal = (basket) =>
    basket?.reduce(
        (amount, item) => amount + item.price, 0
    );

const reducer = (state, action) => {
    // console.log("[ reducer ]: state = ", state);
    // console.log("[ reducer ]: action = ", action);

    switch(action.type) {
        case "ADD_TO_BASKET":
            return {
                ...state,
                basket: [...state.basket, action.item]
            }
        case "REMOVE_FROM_BASKET":
            // Remove only first component with matching ID:
            const index = state.basket.findIndex(
                (basketItem) => basketItem.id === action.item.id
            );
            // console.log("[ reducer ]: remove item index = ", index);

            let newBasket = [...state.basket];

            if (index >= 0) {
                newBasket.splice(index, 1);
            } else {
                console.warn(`Can't remove product with id ${action.item.id} as it's not in the basket!`);
            }
            // console.log("[ reducer ]: newBasket after splice = ", newBasket);

            return {
                ...state,
                basket: newBasket
            }
            // Remove all components with the same ID:
            // return {
            //     ...state,
            //     basket: [...state.basket.filter(item => item.id !== action.item.id)]
            // }
        case 'SET_USER':
            return {
                ...state,
                user: action.user
            }
        case 'EMPTY_BASKET':
            return {
                ...state,
                basket: []
            }
            
        default:
            return state;
    }
}

export default reducer;
